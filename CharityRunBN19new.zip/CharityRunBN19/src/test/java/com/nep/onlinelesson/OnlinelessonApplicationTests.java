package com.nep.onlinelesson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinelessonApplicationTests {

	@Test
	void contextLoads() {
	}

}
