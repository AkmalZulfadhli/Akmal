package sportsApp.controller;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import sportsApp.data.SportsRepository;
import sportsApp.model.Registration;

@Controller
public class EditDeleteController {

	@Autowired
	SportsRepository spRepo;
	String curentParticipantId;
	
	@RequestMapping(value="/editParticipants/{ic_number}")
	public String showEditParticipantsPage(@PathVariable String ic_number, ModelMap modelMap) {
		Registration register = spRepo.findById(ic_number).get();
		modelMap.put("registration", register);
		curentParticipantId = ic_number;
		return "edit-page";
	}
	
	@RequestMapping(value="/editParticipants/{ic_number}/edit")
	public String editParticipants(
			@RequestParam(required=false) String icNumber,
			@RequestParam(required=true) String full_name,
			@RequestParam(required=true) String DOB,
			@RequestParam(required=true) String sports,
			@RequestParam(required=true) String email,
			@PathVariable String ic_number
			) throws ParseException {
		if(curentParticipantId == ic_number) {
			Registration register = spRepo.findById(ic_number).get();
			register.setIcNumber(icNumber);
			register.setName(full_name);
			register.setDOB(DOB);
			register.setSports(sports);
			register.setEmail(email);
			spRepo.save(register);
		}
		return "redirect:/participants";
	}
	
	@RequestMapping(value="/deleteParticipants/{participants_id}")
	public String deleteParticipants(@PathVariable String participants_id) {
		spRepo.deleteById(participants_id);
		return "redirect:/participants";
	}


}
