package sportsApp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import sportsApp.data.SportsRepository;

@Controller
public class MainController {

	@Autowired
	SportsRepository spRepo;
	
	@RequestMapping(value="/")
	public String home(ModelMap modelMap) {
		return "index";
	}
	
	@RequestMapping(value="/about")
	public String aboutUs(ModelMap modelMap) {
		return "about";
	}
	
	@RequestMapping(value="/contact-us")
	public String contactUs(ModelMap modelMap) {
		return "contact-us";
	}
	
	@RequestMapping(value="/schedule")
	public String schedule(ModelMap modelMap) {
		return "schedule";
	}
}
