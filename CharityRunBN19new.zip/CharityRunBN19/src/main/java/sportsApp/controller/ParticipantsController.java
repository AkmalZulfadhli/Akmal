package sportsApp.controller;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import sportsApp.data.SportsRepository;
import sportsApp.model.Registration;

@Controller
public class ParticipantsController  {
	
	@Autowired
	SportsRepository spRepo;
	
	@RequestMapping(value="/participants")
	public String participants(ModelMap modelMap) {
		Iterable<Registration> participants = spRepo.findAll();
		modelMap.put("registration", participants);
		System.out.println(participants);
		return "participants";
	}
	
	@RequestMapping(value="/registration")
	public String addOthers() {
		return "registration";
	}
	
	@RequestMapping(value="/add Participants/add")
	public String addParticipants(
			@RequestParam(required=true) String ic_number,
			@RequestParam(required=true) String full_name,
			@RequestParam(required=true) String DOB,	
			@RequestParam(required=true) String sports,
			@RequestParam(required=true) String email
			) throws ParseException {
		Registration register = new Registration (ic_number, full_name, DOB, sports, email);
		spRepo.save(register);
		return "redirect:/participants";
	}
	
}
